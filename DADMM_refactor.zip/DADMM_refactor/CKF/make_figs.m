classdef make_figs
    properties (Constant)
        labels_params = {'Position x ', 'Position y ', 'Velocity x ', 'Velocity y '};
    end
    
    properties 
        colors;  
    end
    methods 
        function obj = make_figs(numNodes)
            obj.colors = lines(numNodes); % MATLAB function that provides distinct colors
        end
        function plot_converge_across_node(obj,all_estimations_every_iter,true_params,network_topo)
            figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',24);
            for param = 1:4
                subplot(2, 2, param);
                hold on;  % Allows multiple plots on the same axes
            
                % Plot estimations for each node
                for node = 1:network_topo.numNodes
                    plot(squeeze(all_estimations_every_iter(param, node, :)), 'Color', obj.colors(node, :));
                end
            
                % Plot true parameter as a dotted line
                h_true = yline(true_params(param), '--k', 'LineWidth', 1.5);
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['Parameter ' obj.labels_params{param} 'estimates']);
                title([obj.labels_params{param}]);
                legend_entries = arrayfun(@(x) ['Node ' num2str(x)], 1:network_topo.numNodes, 'UniformOutput', false);
                legend_entries{end+1} = 'True Parameter';
                legend([legend_entries], 'Location', 'northeastoutside');
            end
            sgtitle('Parameters of interest (\theta) Estimations');
        end
        function plot_converge_across_node_withCentrl(obj,all_estimations_every_iter,true_params,network_topo, all_estimations_centrl)
            figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',24);
            for param = 1:4
                subplot(2, 2, param);
                hold on;  % Allows multiple plots on the same axes
            
                % Plot estimations for each node
                for node = 1:network_topo.numNodes
                    plot(squeeze(all_estimations_every_iter(param, node, :)), 'Color', obj.colors(node, :));
                end
            
                % Plot true parameter as a dotted line
                h_true = yline(true_params(param), '--k', 'LineWidth', 1.5);
                h_centrl = yline(all_estimations_centrl(param), '--r', 'LineWidth', 1.5);
            
                hold off;
                xlabel('Iterations');
                ylabel(['Parameter ' obj.labels_params{param} 'estimates']);
                title([obj.labels_params{param}]);
                legend_entries = arrayfun(@(x) ['Node ' num2str(x)], 1:network_topo.numNodes, 'UniformOutput', false);
                legend_entries{end+1} = 'True Parameter';
                legend_entries{end+1} = 'Centralized';
                legend([legend_entries], 'Location', 'northeastoutside');
            end
            sgtitle('Parameters of interest (\theta) Estimations');
        end
        function plot_dual_primal_residual(obj,dual_residual_all,primal_residual_CR, all_estimations_every_iter_CR,laplacian_matrix_CR,network_topo)
            % Dual Residual Convergence
            figure;
            semilogy(dual_residual_all);
            xlabel("Iterations (k)");
            % ylabel('|| \nu(k+1) - \nu(k)||_2^2');
            ylabel('$\sum_{n=1}^{N} \sum_{j \in \mathrm{Neighbors}(n)} || \nu_{n|j}(k+1) - \nu{n|j}(k)||_2^2$', 'Interpreter', 'latex');
            title('Dual Residual (s(k))');
            
            % Primal and Dual Convergence for various node ratio
            numColors = length(all_estimations_every_iter_CR);  % Define number of distinct colors needed
            colors = hsv(numColors);  % Creates a colormap with numColors distinct colors
            
            display_node = 1;
            legendNames = cell(1, length(primal_residual_CR)); 
            for i = 1:length(primal_residual_CR)
                legendNames{i} = ['Neighbors: ', num2str(laplacian_matrix_CR{i}(display_node, display_node)), '/', num2str(network_topo.numNodes)];
            end
            
            % Plot Primal Residual Convergence for various node ratios
            figure;
            for CR = 1:numColors
                semilogy(primal_residual_CR{CR}, 'Color', colors(CR, :));
                hold on;
            end
            xlabel('Iterations (k)');
            ylabel('$\sum_{n=1}^{N} \sum_{j \in \mathrm{Neighbors}(n)} ||\theta_m(k+1) - \vartheta_{nj}(k+1)||_2^2$', 'Interpreter', 'latex');
            title('Primal Residual (r(k)) for different node ratios');
            legend(legendNames, 'Location', 'best');  % Add legend with node ratios

        end
        function plot_specific_node_converg(obj,nodeID,com_rad_CR,laplacian_matrix_CR,all_estimations_every_iter_CR,estimated_params_CA, network_topo,true_params)
            % Plot Convergance of theta for various node ratios
            display_node = nodeID;
            legendNames = cell(1, length(com_rad_CR)); 
            
            % Construct the Node Ratio as a fraction in the format 'numerator/denominator'
            for i = 1:length(com_rad_CR)
                legendNames{i} = ['Neighbors: ', num2str(laplacian_matrix_CR{i}(display_node, display_node)), '/', num2str(network_topo.numNodes)];
            end

            figure;
            for param = 1:4
                subplot(2,2,param);
                hold on;
            
                % Initialize a cell array to store plot handles
                hPlots = cell(1, length(all_estimations_every_iter_CR) + 2); % +2 for true parameter and centralized approach
            
                % Plot all estimations with specific color and store handles
                for j = 1:length(all_estimations_every_iter_CR)
                    hPlots{j} = plot(squeeze(all_estimations_every_iter_CR{j}(param, display_node, :)), 'Color', obj.colors(j, :));        
                end
            
                % Plot the centralized approach as a yline
                hPlots{end-1} = yline(estimated_params_CA(param), 'k', 'LineWidth', 1.5, 'DisplayName', 'Centralized Approach');
            
                % Plot the true parameter line and store the handle
                hPlots{end} = yline(true_params(param), '--k', 'LineWidth', 1.5, 'DisplayName', 'True Parameter');
            
                % Add the legend
                legend([hPlots{:}], [legendNames, {'Centralized Approach', 'True Parameter'}]);
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['Parameter ' obj.labels_params{param} ' estimates']);
                title([obj.labels_params{param}]);
            
                hold off;
            
            
            end
            
            sgtitle({'Convergence of parameters of interest ($\theta_n$) at $n^{\mathrm{th}}$ node for different communication radius'}, 'Interpreter', 'latex');
            % sgtitle({'Convergence of parameters of interest ($\theta_n$) at',nodeID ,'th node for different communication radius'}, 'Interpreter', 'latex');
        end
        function plot_sepcific_node_error_converg(obj,all_estimations_every_iter_mc,estimates_mc_CA,direction_mc,true_params_mc)
            
            colors_size = size(direction_mc, 1);
            colors = hsv(colors_size);
            legendNames = cell(1, size(direction_mc, 1)); 
            
            % Construct the legend names based on the rows of direction_mc
            for i = 1:size(direction_mc, 1)
                    % Format the direction values to two decimal places
                    directionStr = num2str(direction_mc(i, :), '%0.2f ');
                    legendNames{i} = ['Direction: ', directionStr];
            end
            
            figure;
            for param = 1:4
                subplot(2,2,param);
                hold on;
                display_node = 1;
                % Initialize a cell array to store plot handles
                hPlots = cell(1, length(all_estimations_every_iter_mc)+2); % +2 for centralized approach and true parameter error line
            
                % Plot estimation errors with specific color and store handles
                for j = 1:length(all_estimations_every_iter_mc)
                    % Calculate estimation error as estimation minus true parameter
                    errors = squeeze(all_estimations_every_iter_mc{j}{:}(param, display_node, :)) - true_params_mc(j,param);
                    hPlots{j} = semilogy(errors, 'Color', colors(j, :));        
                end
            
                % Plot the centralized approach error as a horizontal line at zero (assuming centralized approach estimates the parameter correctly)
                hPlots{end-1} = yline(estimates_mc_CA(j,param) - true_params_mc(j,param), 'k', 'LineWidth', 1.5, 'DisplayName', 'Centralized Approach Error');
            
                % Plot the true parameter error line (which should be zero) and store the handle
                hPlots{end} = yline(0, '--k', 'LineWidth', 1.5, 'DisplayName', 'Zero Error');
            
                % Add the legend
                legend([hPlots{:}], [legendNames, {'Centralized Approach Error', 'Zero Error'}]);
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['Error for ' obj.labels_params{param}]);
                title(['Error in ' obj.labels_params{param}]);
            
            end
            
            sgtitle({'Error convergence for parameters of interest ($\theta_n$) at $n^{\mathrm{th}}$ node for different communication radius'}, 'Interpreter', 'latex');

        end
        function plot_MSE_error(obj,direction_mc,all_estimations_every_iter_mc,true_params_mc)
            % Plot MSE Error (Estimated(with neighbors ratio) - True Params).^2
            % Plotting Errors (\hat{\theta} - \theta).^2 results
            display_node = 1;
            legendNames = cell(1, size(direction_mc, 1)); 
            
            % Construct the legend names based on the rows of direction_mc
            for i = 1:size(direction_mc, 1)
                    % Format the direction values to two decimal places
                    directionStr = num2str(direction_mc(i, :), '%0.2f ');
                    legendNames{i} = ['Direction: ', directionStr];
            end
            
            figure;
            for param = 1:4
                subplot(2,2,param);
                hold on;

                % Initialize a cell array to store plot handles
                hPlots = cell(1, length(all_estimations_every_iter_mc)); % +2 for centralized approach and true parameter error line
            
                % Plot estimation errors with specific color and store handles
                for j = 1:length(all_estimations_every_iter_mc)
                    % Calculate estimation error as estimation minus true parameter
                    errors = (squeeze(all_estimations_every_iter_mc{j}{:}(param, display_node, :)) - true_params_mc(j,param)).^2;
                    hPlots{j} = semilogy(errors, 'Color', obj.colors(j, :));        
                end
                set(gca, 'YScale', 'log');
            
                % Plot the centralized approach error as a horizontal line at zero (assuming centralized approach estimates the parameter correctly)
            %     hPlots{end-1} = yline((estimates_mc_CA(j,param) - true_params_mc(j,param)).^2, 'k', 'LineWidth', 1.5, 'DisplayName', 'Centralized Approach Error');
            %     
            %     % Plot the true parameter error line (which should be zero) and store the handle
            %     hPlots{end} = yline(0, '--k', 'LineWidth', 1.5, 'DisplayName', 'Zero Error');
            %     
                % Add the legend
            %     legend([hPlots{:}], [legendNames, {'Centralized Approach Error', 'Zero Error'}]);
                legend([hPlots{:}], legendNames);
                hold off;
                xlabel('Iterations (k)');
                ylabel(['MSE for ' obj.labels_params{param}]);
                title(['MSE in ' obj.labels_params{param}]);
            
            end    
            sgtitle({'MSE convergence for parameters of interest ($\theta_n$) at $n^{\mathrm{th}}$ node for different communication radius'}, 'Interpreter', 'latex');
        end 
        function plot_errors_all_neighbors(obj, com_rad_CR, laplacian_matrix_CR,all_estimations_every_iter_CR, estimated_params_CA, network_topo,true_params)
            % Plotting Errors (\hat{\theta} - \theta) results for all neighbors
            display_node = 1;
            numColors = length(all_estimations_every_iter_CR); 
            colors = hsv(numColors);
            labels_params = {'Position x', 'Position y', 'Velocity x', 'Velocity y'};
            legendNames = cell(1, length(com_rad_CR)); 
            
            % Construct the Node Ratio as a fraction in the format 'numerator/denominator'
            for i = 1:length(com_rad_CR)
                legendNames{i} = ['Neighbors: ', num2str(laplacian_matrix_CR{i}(display_node, display_node)), '/', num2str(network_topo.numNodes)];
            end
            
            figure;
            for param = 1:4
                subplot(2,2,param);
                hold on;
            
                % Initialize a cell array to store plot handles
                hPlots = cell(1, length(all_estimations_every_iter_CR) + 2); % +2 for centralized approach and true parameter error line
            
                % Plot estimation errors with specific color and store handles
                for j = 1:length(all_estimations_every_iter_CR)
                    % Calculate estimation error as estimation minus true parameter
                    errors = squeeze(all_estimations_every_iter_CR{j}(param, display_node, :)) - true_params(param);
                    hPlots{j} = semilogy(errors, 'Color', colors(j, :));        
                end
            
                % Plot the centralized approach error as a horizontal line at zero (assuming centralized approach estimates the parameter correctly)
                hPlots{end-1} = yline(estimated_params_CA(param) - true_params(param), 'k', 'LineWidth', 1.5, 'DisplayName', 'Centralized Approach Error');
            
                % Plot the true parameter error line (which should be zero) and store the handle
                hPlots{end} = yline(0, '--k', 'LineWidth', 1.5, 'DisplayName', 'Zero Error');
            
                % Add the legend
                legend([hPlots{:}], [legendNames, {'Centralized Approach Error', 'Zero Error'}]);
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['$(', '\hat{\theta}_n', ' - \theta)$' ], 'Interpreter', 'latex');
                title(['For ' obj.labels_params{param}]);
            
            end
            
            sgtitle({'$\left(\hat{\theta}_n - \theta\right)$ for different neighbor nodes'}, 'Interpreter', 'latex');
        end 
        function plot_MSE_for_all_neightbors(obj,com_rad_CR,laplacian_matrix_CR,estimated_params_CA,all_estimations_every_iter_CR,true_params,network_topo)
            % For MSE fo all neighbors
            display_node = 1;
            legendNames = cell(1, length(com_rad_CR)); 
            
            % Construct the Node Ratio as a fraction in the format 'numerator/denominator'
            for i = 1:length(com_rad_CR)
                legendNames{i} = ['Neighbors: ', num2str(laplacian_matrix_CR{i}(display_node, display_node)), '/', num2str(network_topo.numNodes)];
            end
            figure;
            for param = 1:4
                subplot(2,2,param);
                hold on;
            
                % Initialize a cell array to store plot handles
                hPlots = cell(1, length(all_estimations_every_iter_CR) + 2); % +2 for centralized approach and true parameter error line
            
                % Plot estimation errors with specific color and store handles
                for j = 1:length(all_estimations_every_iter_CR)
                    % Calculate estimation error as estimation minus true parameter
                    errors = (squeeze(all_estimations_every_iter_CR{j}(param, display_node, :)) - true_params(param)).^2;
                    hPlots{j} = semilogy(errors, 'Color', obj.colors(j, :));        
                end
            
                % Plot the centralized approach error as a horizontal line at zero (assuming centralized approach estimates the parameter correctly)
                hPlots{end-1} = yline((estimated_params_CA(param) - true_params(param)).^2, 'k', 'LineWidth', 1.5, 'DisplayName', 'Centralized Approach Error');
            
                % Plot the true parameter error line (which should be zero) and store the handle
                hPlots{end} = yline(0, '--k', 'LineWidth', 1.5, 'DisplayName', 'Zero Error');
            
                % Add the legend
                legend([hPlots{:}], [legendNames, {'Centralized Approach Error', 'Zero Error'}]);
            
                set(gca, 'YScale', 'log');  % Set the Y-axis to logarithmic scale
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['$(', '\hat{\theta}_n', ' - \theta)^2$'], 'Interpreter', 'latex');
                title(['For ' obj.labels_params{param}]);
            
                % The rest of your code for the inset plots
                % Ensure to set 'YScale' to 'log' for the inset axes if needed
            end
            
            sgtitle({'$\left(\hat{\theta}_n - \theta\right)^2$ for Different neighbors ratio'}, 'Interpreter', 'latex');
        end
        function plot_MSE_error_compare_DA_DS(obj,direction_mc,all_estimations_every_iter_mc,estimates_mc_CA, true_params_mc)
            % Plot MSE error for (\hat{\theta} - \theta).^2 with Decentralized as straight line and distributed as dashed
            display_node = 5;
            legendNames = cell(1, size(direction_mc, 1)); 
            colors_size = size(direction_mc, 1);
            colors = hsv(colors_size);
            % Construct the legend names based on the rows of direction_mc
            for i = 1:size(direction_mc, 1)
                    % Format the direction values to two decimal places
                    directionStr = num2str(direction_mc(i, :), '%0.2f ');
                    legendNames{i} = ['Direction: ', directionStr];
            end
            figure;
            legendEntries = {};  % Initialize an empty cell array to hold legend entries
            for param_idx = 1:4
                subplot(2,2,param_idx);
                hold on;
                legendEntries = {};
                % Initialize a cell array to store plot handles
                hPlots = []; % Use a simple array to store handles
            
                for j = 1:length(all_estimations_every_iter_mc)
                    % Define colors for this particular direction
                    color = colors(j, :);
            
                    % Calculate errors for decentralized
                    errors = (squeeze(all_estimations_every_iter_mc{j}{:}(param_idx, display_node, :)) - true_params_mc(j,param_idx)).^2;
                    % Decentralized plot (straight line)
                    hPlotDecentralized = semilogy(errors, 'Color', color, 'LineStyle', '-');
                    hPlots = [hPlots, hPlotDecentralized];  % Append handle
                    legendEntries{end+1} = [legendNames{j}, ' Decentralized'];  % Append legend entry
            
                    % Calculate centralized estimation error
                    ca_error = (estimates_mc_CA(j,param_idx) - true_params_mc(j,param_idx)).^2;
                    % Centralized plot (dashed line) using the same color
                    hPlotCentralized = semilogy(1:length(errors), repmat(ca_error, 1, length(errors)), 'Color', color, 'LineStyle', '--');
                    hPlots = [hPlots, hPlotCentralized];  % Append handle
                    legendEntries{end+1} = [legendNames{j}, ' Centralized'];  % Append legend entry
                end
            
                set(gca, 'YScale', 'log');
                legend(hPlots, legendEntries, 'Location', 'best');
            
                hold off;
                xlabel('Iterations (k)');
                ylabel(['$(', '\hat{\theta}_n', ' - \theta)^2$'], 'Interpreter', 'latex');
                title(['For ' obj.labels_params{param_idx}]);
            end
            
            sgtitle('$\left(\hat{\theta}_n - \theta\right)^2$ for different directions with 19/20 neighbors', 'Interpreter', 'latex');

        end
        function plot_predictions(obj, time_vector, all_predictions, true_trajectory, network_topo)
            figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',24);
            subplot(2,1,1);
            hold on;
            for t = 1: length(time_vector)
                plot(all_predictions{t}(:,1),all_predictions{t}(:,2),'o','Color',[0.8 0.8 0.8]);
                plot(true_trajectory(1,t),true_trajectory(2,t),'k*','MarkerSize',10);
            end
            for node = 1:network_topo.numNodes
                plot(time_vector, squeeze(all_predictions(1, node, :)), 'Color', obj.colors(node, :));
            end
            plot(time_vector, true_trajectory(1, :), '--k', 'LineWidth', 1.5);
            hold off;
            xlabel('Time (s)');
            ylabel('Position x (m)');
            title('Position x Predictions');
            legend_entries = arrayfun(@(x) ['Node ' num2str(x)], 1:network_topo.numNodes, 'UniformOutput', false);
            legend_entries{end+1} = 'True Trajectory';
            legend([legend_entries], 'Location', 'northeastoutside');
            
            subplot(2,1,2);
            hold on;
            for node = 1:network_topo.numNodes
                plot(time_vector, squeeze(all_predictions(2, node, :)), 'Color', obj.colors(node, :));
            end
            plot(time_vector, true_trajectory(2, :), '--k', 'LineWidth', 1.5);
            hold off;
            xlabel('Time (s)');
            ylabel('Position y (m)');
            title('Position y Predictions');
            legend_entries = arrayfun(@(x) ['Node ' num2str(x)], 1:network_topo.numNodes, 'UniformOutput', false);
            legend_entries{end+1} = 'True Trajectory';
            legend([legend_entries], 'Location', 'northeastoutside');
        end
        function plot_trajectory(obj, true_trajectory, estimated_trajectory)
            % Shape of the inputs:
            % true_trajectory: [Num target, track_time, 2]
            % estimated_trajectory: cell(track_time): [4 x 1]
            estimated_trajectory = cell2mat(estimated_trajectory);
            figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',24);
            hold on;
            % plot(true_trajectory(1, :, 1), true_trajectory(1, :, 2), '--r', 'LineWidth', 1, 'DisplayName', 'True Trajectory');
            plot(true_trajectory(1, 1:size(true_trajectory,2)-64, 1),true_trajectory(1, 1:size(true_trajectory,2)-64, 2), '-r', 'LineWidth', 1, 'DisplayName', 'Ground truth location');
            plot(estimated_trajectory(1,:), estimated_trajectory(2,:), '--ob', 'LineWidth', 1.5, 'DisplayName', 'Estimated Trajectory');
            hold off;
            xlabel('Position x (m)');
            ylabel('Position y (m)');
            title('Target Trajectory');
            legend('Location', 'northeastoutside');
        end
        function plot_geometry_and_target(obj, network_topo, target_position)
            figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',24);
            hold on;
            plot(network_topo.radar_pos(:,1), network_topo.radar_pos(:,2), 'rs', 'MarkerSize', 10, 'DisplayName', 'Sensor Nodes');
            plot(target_position(1), target_position(2), 'k*', 'MarkerSize', 10, 'DisplayName', 'Target Position');
            hold off;
            xlabel('Position x (m)');
            ylabel('Position y (m)');
            title('Network Geometry and Target Position');
            legend('Location', 'northeastoutside');
        end
        function plot_trajectory_and_network(obj, true_trajectory, estimated_trajectory,network_topo)
            % Shape of the inputs:
            % true_trajectory: [Num target, track_time, 2]
            % estimated_trajectory: cell(track_time): [4 x 1]
            estimated_trajectory = cell2mat(estimated_trajectory);
            fig = figure;
            set(gcf,'Color','white');
            set(gca,'FontSize',35);
            hold on;
            gt = plot(true_trajectory(1, :, 1), true_trajectory(1, :, 2), '-ok', 'LineWidth', 2, 'DisplayName', 'True Trajectory');
            gt.MarkerIndices = 1:10:length(true_trajectory(1, :, 1));
            plot(network_topo.radar_pos(:,1), network_topo.radar_pos(:,2), 'r.', 'MarkerSize', 50, 'DisplayName', 'Sensor Nodes');
            % plot(true_trajectory(1, 1:size(true_trajectory,2)-64, 1),true_trajectory(1, 1:size(true_trajectory,2)-64, 2), '-r', 'LineWidth', 1, 'DisplayName', 'Ground truth location');
            pred = plot(estimated_trajectory(1,:), estimated_trajectory(2,:), '--ob', 'LineWidth', 2, 'DisplayName', 'Estimated Trajectory');
            pred.MarkerIndices = 1:10:length(estimated_trajectory(1,:));
            hold off;
            xlabel('Position x (m)');
            ylabel('Position y (m)');
            % title('Target Trajectory');
            legend('Location', 'best');
            grid on;box on;ax=gca;ax.LineWidth=1.5;
            exportgraphics(fig, 'output.pdf', 'ContentType', 'vector');
        end

        function plot_trajectory_and_network_and_mse(obj, true_trajectory, estimated_trajectory,network_topo,mse,LEGOFF,NumMark)
            % Shape of the inputs:
            % true_trajectory: [Num target, track_time, 2]
            % estimated_trajectory: cell(track_time): [4 x 1]
            estimated_trajectory = cell2mat(estimated_trajectory);
            % ax1 = subplot(2,2,[1,3]);
            % cla(ax1);
            % hold(ax1,'on');
            % 
            % set(gcf,'Color','white');
            % set(gca,'FontSize',25);
            % hold on;
            % if ~LEGOFF
            %     gt = plot(true_trajectory(1, :, 1), true_trajectory(1, :, 2), '-k', 'LineWidth', 2, 'HandleVisibility', 'off','MarkerSize',20);
            %     % gt.MarkerIndices = 1:floor(length(true_trajectory(1,:,1))/500):length(true_trajectory(1, :, 1));
            %     step = max(1, floor(length(true_trajectory(1,:,2))/20));
            %     gt.MarkerIndices = 1:step:length(true_trajectory(1,:,2));
            %     plot(network_topo.radar_pos(:,1), network_topo.radar_pos(:,2), 'r.', 'MarkerSize', 50,'HandleVisibility', 'off');
            %     % plot(true_trajectory(1, 1:size(true_trajectory,2)-64, 1),true_trajectory(1, 1:size(true_trajectory,2)-64, 2), '-r', 'LineWidth', 1, 'DisplayName', 'Ground truth location');
            %     pred = plot(estimated_trajectory(1,:), estimated_trajectory(2,:), '-->b', 'LineWidth', 2, 'HandleVisibility', 'off','MarkerSize',10);
            %     % pred.MarkerIndices = 1:floor(length(estimated_trajectory(1,:))/500):length(estimated_trajectory(1,:));
            %     step = max(1, floor(length(estimated_trajectory(1,:))/20));
            %     pred.MarkerIndices = 1:step:length(estimated_trajectory(1,:));
            % else
            %     gt = plot(true_trajectory(1, :, 1), true_trajectory(1, :, 2), '-k', 'LineWidth', 2, 'DisplayName', 'True Trajectory','MarkerSize',20);
            %     % gt.MarkerIndices = 1:floor(length(true_trajectory(1,:,1))/500):length(true_trajectory(1, :, 1));
            %     step = max(1, floor(length(true_trajectory(1,:,2))/20));
            %     gt.MarkerIndices = 1:step:length(true_trajectory(1,:,2));
            %     plot(network_topo.radar_pos(:,1), network_topo.radar_pos(:,2), 'r.', 'MarkerSize', 50, 'DisplayName', 'Sensor Nodes');
            %     % plot(true_trajectory(1, 1:size(true_trajectory,2)-64, 1),true_trajectory(1, 1:size(true_trajectory,2)-64, 2), '-r', 'LineWidth', 1, 'DisplayName', 'Ground truth location');
            %     pred = plot(estimated_trajectory(1,:), estimated_trajectory(2,:), '-->b', 'LineWidth', 2, 'DisplayName', 'Estimated Trajectory','MarkerSize',10);
            %     % pred.MarkerIndices = 1:floor(length(estimated_trajectory(1,:))/500):length(estimated_trajectory(1,:));
            %     step = max(1, floor(length(estimated_trajectory(1,:))/20));
            %     pred.MarkerIndices = 1:step:length(estimated_trajectory(1,:));
            % end
            % hold off;
            % xlabel('Position x (m)');
            % ylabel('Position y (m)');
            % % title('Target Trajectory');
            % legend('Location', 'southeast');
            % grid on;box on;ax=gca;ax.LineWidth=1.5;

            ax1 = subplot(2,2,[1,3]);
            cla(ax1);
            hold(ax1,'on');
            set(gcf,'Color','white');
            set(ax1,'FontSize',25);
            
            % true trajectory
            gt = plot(ax1, true_trajectory(1,:,1), true_trajectory(1,:,2), '-k', ...
                'LineWidth', 2, 'DisplayName', 'True Trajectory');
            
            % sensor nodes
            plot(ax1, network_topo.radar_pos(:,1), network_topo.radar_pos(:,2), 'r.', ...
                'MarkerSize', 50, 'DisplayName', 'Sensor Nodes');
            
            % estimated trajectory line only
            pred = plot(ax1, estimated_trajectory(1,:), estimated_trajectory(2,:), '--b', ...
                'LineWidth', 2, 'HandleVisibility', 'off');
            
            % Choose fewer index to visualized
            % predstep = max(1, floor(length(estimated_trajectory(1,:))/20));
            % pred.MarkerIndices = 1:predstep:length(estimated_trajectory(1,:));

            % sparse markers only
            Nmarker = NumMark;   % 你想顯示幾個 marker
            idx = unique(round(linspace(1, size(estimated_trajectory,2), Nmarker)));
            
            plot(ax1, estimated_trajectory(1,idx), estimated_trajectory(2,idx), '-ob', ...
                'LineStyle', 'none', 'MarkerSize', 8, 'DisplayName', 'Estimated Trajectory','LineWidth',2);

            xlabel(ax1,'Position x (m)');
            ylabel(ax1,'Position y (m)');
            legend(ax1,'Location','southeast');
            grid(ax1,'on');
            box(ax1,'on');
            ax1.LineWidth = 1.5;
            hold(ax1,'off');



            
            mse_mat = mse(1,:);
            titles = {'x', 'y', 'v_x', 'v_y'};
            
            T = numel(mse_mat);
            mse_array = zeros(T,4);
            
            for t = 1:T
                mse_array(t,:) = mse_mat{t};
            end
            
            state_names = {'RMSE X', 'RMSE Y', 'v_x', 'v_y'};
            label_fs = 25;
            tick_fs  = 20;
            title_fs = 20;
            set(gcf,'Color','white');
            for i = 1:2
                if i == 1
                    ax2 = subplot(2,2,2);
                    cla(ax2);
                    hold(ax2,'on');
                elseif i == 2
                    ax3 = subplot(2,2,4);
                    cla(ax3);
                    hold(ax3,'on');
                end
                plot(1:T, mse_array(:,i), 'LineWidth', 2);
                grid on;
                xlim([1 1920]);
                xlabel('time k (ms)', 'FontSize', label_fs);
                ylabel('RMSE', 'FontSize', label_fs);
                title(state_names{i}, 'FontSize', title_fs);
            
                ax = gca;
                ax.FontSize = tick_fs;   % tick label size
            end
        end 
    end
end